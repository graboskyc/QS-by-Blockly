<?php
//////////////////////////
// CONFIGURATION
//////////////////////////
$QS_PathToCSPython = 'C:\Program Files (x86)\QualiSystems\TestShell\ExecutionServer\python\2.7.10\python.exe';
$QS_PathToGetDetails = 'C:\inetpub\wwwroot\getDetails.py';
$QS_PathToUploadPkg = 'C:\inetpub\wwwroot\uploadPackage.py';
?>